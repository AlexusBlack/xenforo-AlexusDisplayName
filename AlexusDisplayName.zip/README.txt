Thank you for downloading Display Name by Alex Chernov.

INSTALLATION:

To use this plugin you need to install Custom Fields by Waindigo first - 
https://xenforo.com/community/resources/th-custom-fields.885/

To install this add-on, you will need to extract the zip and upload all the
files from the contained upload directory onto your web server into the root
folder of your XenForo Directory.

Having uploaded the necessary files, you should log in to the Admin Control
Panel of your XenForo Installation and click on 'Install Add-on' under the
heading 'Add-ons' on the left-hand side of the Admin Control Panel under the
'Home' tab.

Upload file called 'addon-AlexusDisplayName.xml'.

If you are not able to find 'Display Name' in Users -> Custom User Fields, you
can import it manually from 'field-AlexusDisplayName.xml' file.